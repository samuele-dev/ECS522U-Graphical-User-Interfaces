import React from 'react';
import Styles from './NavigationBar.module.css';
import ButtonStyles from './NavigationElements/NavigationElement.module.css';
import NavigationElement from './NavigationElements/NavigationElement.js'

class NavigationBar extends React.Component{
    //constructor for the navigation bar
    constructor(props){
      super(props)
      this.setActiveToday = this.setActiveToday.bind(this)
      
      this.state = {
        TodayToggle: ButtonStyles.NavigationElementActive,
      }
    }

    setActiveToday(){
      this.setState({
        TodayToggle: ButtonStyles.NavigationElementActive
      })
    }
    
    // Shows the navigation bar with a single navigation element
    render(){
        return (
            <div className={Styles.NavigationBar}>
              <NavigationElement text="Today" className={this.state.TodayToggle} click={this.setActiveToday}/>
            </div>
          );
    }
}

export default NavigationBar;
