import React from 'react';
import Style from "./settings.module.css";

// Structure of the settings button icon
class SettingsButton extends React.Component{
        render(){
            return (
                <div className={Style.settingPane}>
                    <button>Show</button>
                    <div>
                        <div>Hello World</div>
                    </div>
                </div>
            )
        }
}

export default SettingsButton;