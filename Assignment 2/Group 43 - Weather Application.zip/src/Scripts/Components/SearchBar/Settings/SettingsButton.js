import React from 'react';
import Styles from "./settings.module.css";
import StylesPane from "./SettingsPane.Module.css"

class SettingsButton extends React.Component{
    // When user click on the button icon, do the following...
    openPopUp(){
        // Dims the background to place emphasis on settings
        const element = document.getElementsByClassName(StylesPane.HideBackPanel)[0]
        element.className = StylesPane.BackPanel
        // Shows the settings panel
    }
        // Structure of the settings button.
        render(){
            return (
                    <button className={Styles.SettingsButton} onClick={this.openPopUp}>
                        <svg className={Styles.burgerKing}>
                            <path d="M0,11 7,11" stroke="#000" strokeWidth="7.3"/>
                            <path d="M0,22 7,22" stroke="#000" strokeWidth="7.3"/>
                            <path d="M0,33 7,33" stroke="#000" strokeWidth="7.3"/>
                        </svg>
                    </button>
               
            )
        }
}

export default SettingsButton;