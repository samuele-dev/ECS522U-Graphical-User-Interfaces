*********************
Group 43 Weather App
*********************

This project was bootstrapped with [Create React App]



********************
Project Setup Guide
********************

In the project directory, you must:

1) Install dependencies - Run `npm install`

Run `npm install` to install all dependencies for the project in a ' node_modules ' folder

2) Run Project - `npm start`

Runs the app in the development mode.
Open [http://localhost:3000] to view it in the browser.



************
Contributors
************

Antonio-Alexandru Caragheorghe
Hamima Zainab
Samuele Joshi
Tomas Hrdlicka
Vakisan Manoharan