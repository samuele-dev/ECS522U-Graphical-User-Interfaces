# Group 43 Weather App

This project was bootstrapped with [Create React App]
<br/>
<br/>
<br/>

## Project Setup Guide
In the project directory, you must:
<br/>

### 1) Install dependencies - Run `npm install`

Run `npm install` to install all dependencies for the project in a ' node_modules ' folder
<br/>

### 2) Run Project - `npm start`

Runs the app in the development mode.
Open [http://localhost:3000] to view it in the browser.
<br/>
<br/>
<br/>

## Contributors

`Antonio-Alexandru Caragheorghe`<br/>
`Hamima Zainab`<br/>
`Samuele Joshi`<br/>
`Tomas Hrdlicka`<br/>
`Vakisan Manoharan`<br/>
